import { useEffect, useMemo, useState } from 'react'
import $ from 'jquery'
import { ContactRound, Plus, Search, Phone, Trash2, Smartphone, ShieldCheck, Users, X } from 'lucide-react'

const digits = (value) => value.replace(/[^\d+]/g, '')

export default function App() {
  const [contacts, setContacts] = useState([])
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [search, setSearch] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  function loadContacts() {
    try {
      const saved = JSON.parse(localStorage.getItem('mobile-number-contacts') || '[]')
      setContacts(Array.isArray(saved) ? saved : [])
    } catch {
      setContacts([])
      setError('خواندن مخاطبان ذخیره‌شده با مشکل روبه‌رو شد.')
    }
  }
  useEffect(() => { loadContacts() }, [])
  function persistContacts(nextContacts) {
    localStorage.setItem('mobile-number-contacts', JSON.stringify(nextContacts))
    setContacts(nextContacts)
  }
  // jQuery is included as requested; this small enhancement focuses the first field when the form is opened.
  useEffect(() => { $('#contact-name').trigger('focus') }, [])

  const filtered = useMemo(() => contacts.filter(c =>
    `${c.name} ${c.phone}`.toLowerCase().includes(search.toLowerCase().trim())
  ), [contacts, search])

  async function handleSubmit(e) {
    e.preventDefault()
    setMessage(''); setError('')
    if (!name.trim() || !phone.trim()) { setError('لطفاً نام و شماره موبایل را وارد کن.'); return }
    setSaving(true)
    try {
      const normalizedPhone = phone.trim()
      if (contacts.some(c => c.phone === normalizedPhone)) throw new Error('این شماره قبلاً ذخیره شده است.')
      const data = { id: Date.now(), name: name.trim(), phone: normalizedPhone, created_at: new Date().toISOString() }
      persistContacts([data, ...contacts])
      setName(''); setPhone('')
      setMessage('مخاطب با موفقیت روی همین گوشی ذخیره شد.')
      $('#contact-name').trigger('focus')
    } catch (err) { setError(err.message || 'ذخیره مخاطب انجام نشد.') }
    finally { setSaving(false) }
  }

  async function removeContact(id) {
    if (!window.confirm('این مخاطب حذف شود؟')) return
    try {
      persistContacts(contacts.filter(c => c.id !== id))
      setMessage('مخاطب حذف شد.')
      setError('')
    } catch { setError('حذف مخاطب انجام نشد.') }
  }

  return <main className="min-h-screen px-4 py-8 sm:px-6">
    <div className="mx-auto max-w-5xl">
      <header className="mb-8 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="brand-icon"><Smartphone size={25} /></div>
          <div><p className="text-xl font-black tracking-tight text-white">دفتر شماره‌ها</p><p className="mt-1 text-xs text-slate-400">ساده، مرتب، همیشه در دسترس</p></div>
        </div>
        <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-300 sm:flex"><ShieldCheck size={15} className="text-emerald-400" /> ذخیره‌سازی آفلاین روی گوشی</div>
      </header>

      <section className="hero-panel mb-6 overflow-hidden rounded-3xl p-6 sm:p-9">
        <div className="relative z-10 max-w-xl">
          <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1.5 text-xs font-bold text-cyan-200"><ContactRound size={14} /> مخاطبین شخصی</span>
          <h1 className="text-3xl font-black leading-tight text-white sm:text-4xl">شماره‌هات رو <span className="text-cyan-300">مرتب نگه دار.</span></h1>
          <p className="mt-3 max-w-md text-sm leading-7 text-slate-300">نام و شماره موبایل رو وارد کن؛ مخاطب‌ها در پایگاه داده ذخیره می‌شن و هر وقت بخوای می‌تونی پیداشون کنی.</p>
          <div className="mt-6 flex items-center gap-3 text-sm text-slate-300"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10"><Users size={18} /></span><span><b className="text-white">{contacts.length}</b> مخاطب ذخیره‌شده</span></div>
        </div>
        <div className="hero-orb"><Phone size={66} strokeWidth={1.1} /></div>
      </section>

      <div className="grid gap-6 lg:grid-cols-[0.85fr_1.15fr]">
        <section className="panel h-fit rounded-3xl p-5 sm:p-6">
          <div className="mb-5 flex items-center gap-3"><div className="section-icon"><Plus size={20} /></div><div><h2 className="font-extrabold text-white">افزودن مخاطب</h2><p className="mt-1 text-xs text-slate-400">اطلاعات مخاطب جدید رو وارد کن</p></div></div>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><label htmlFor="contact-name" className="mb-2 block text-sm font-semibold text-slate-300">نام مخاطب</label><input id="contact-name" value={name} onChange={e => setName(e.target.value)} placeholder="مثلاً علی رضایی" maxLength={80} className="field" /></div>
            <div><label htmlFor="contact-phone" className="mb-2 block text-sm font-semibold text-slate-300">شماره موبایل</label><div className="relative"><Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" size={17} /><input id="contact-phone" type="tel" inputMode="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="09123456789" maxLength={20} className="field pr-11" dir="ltr" /></div></div>
            {error && <p role="alert" className="notice error">{error}</p>}
            {message && <p role="status" className="notice success">{message}</p>}
            <button type="submit" disabled={saving} className="primary-btn"><Plus size={18} />{saving ? 'در حال ذخیره...' : 'ذخیره مخاطب'}</button>
          </form>
          <p className="mt-4 text-center text-[11px] leading-5 text-slate-500">اطلاعات به‌صورت محلی روی همین گوشی ذخیره می‌شود؛ برای استفاده به اینترنت نیاز نیست.</p>
        </section>

        <section className="panel rounded-3xl p-5 sm:p-6">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-extrabold text-white">مخاطب‌های من</h2><p className="mt-1 text-xs text-slate-400">فهرست شماره‌های ذخیره‌شده</p></div><span className="count-pill">{filtered.length} مورد</span></div>
          <div className="relative mb-4"><Search size={17} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="جست‌وجو با نام یا شماره..." className="field pr-11" /></div>
          <div className="contact-list">
            {filtered.length === 0 ? <div className="empty-state"><div className="empty-icon"><ContactRound size={28} /></div><p className="font-bold text-slate-300">{search ? 'مخاطبی پیدا نشد' : 'هنوز مخاطبی نداری'}</p><p className="mt-2 text-xs text-slate-500">{search ? 'عبارت دیگری رو امتحان کن.' : 'اولین شماره رو از فرم کناری ذخیره کن.'}</p></div> :
              filtered.map((contact, index) => <article key={contact.id} className="contact-row">
                <div className="avatar">{contact.name.trim().charAt(0) || '؟'}</div>
                <div className="min-w-0 flex-1"><p className="truncate text-sm font-bold text-slate-100">{contact.name}</p><a href={`tel:${digits(contact.phone)}`} dir="ltr" className="mt-1 inline-block text-sm text-cyan-300 hover:text-cyan-200">{contact.phone}</a></div>
                <a className="icon-btn call-btn" href={`tel:${digits(contact.phone)}`} aria-label={`تماس با ${contact.name}`}><Phone size={16} /></a>
                <button className="icon-btn delete-btn" onClick={() => removeContact(contact.id)} aria-label={`حذف ${contact.name}`}><Trash2 size={16} /></button>
              </article>)
            }
          </div>
        </section>
      </div>
      <footer className="mt-8 text-center text-xs text-slate-600">دفتر شماره‌ها <span className="mx-1">•</span> ساخته‌شده با React، Tailwind CSS و Capacitor</footer>
    </div>
  </main>
}